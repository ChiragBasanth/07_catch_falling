"""
Basket: the player-controlled catcher at the bottom of the screen.
"""

import pygame

BOOST_DURATION = 180   # frames the boost lasts (3 s at 60 FPS)
BOOST_COOLDOWN = 300   # frames before boost can be used again (5 s)
BOOST_MULTIPLIER = 2


class Basket:
    def __init__(self, x, y, width=90, height=24, speed=5):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.normal_speed = speed
        self.boost_speed = speed * BOOST_MULTIPLIER
        self.speed = speed
        self.vel = 0.0
        self.boost_frames_left = 0
        self.cooldown_frames_left = 0

    @property
    def is_boosted(self):
        return self.boost_frames_left > 0

    def boost_fraction(self):
        return self.boost_frames_left / BOOST_DURATION

    def cooldown_fraction(self):
        return self.cooldown_frames_left / BOOST_COOLDOWN

    def activate_boost(self):
        if self.boost_frames_left == 0 and self.cooldown_frames_left == 0:
            self.boost_frames_left = BOOST_DURATION
            self.speed = self.boost_speed

    def update_boost(self):
        if self.boost_frames_left > 0:
            self.boost_frames_left -= 1
            if self.boost_frames_left == 0:
                self.speed = self.normal_speed
                self.cooldown_frames_left = BOOST_COOLDOWN
        elif self.cooldown_frames_left > 0:
            self.cooldown_frames_left -= 1

    def move(self, direction, screen_width):
        """direction: -1 left, 0 none, 1 right. Smooth acceleration, stays fully on screen."""
        target = direction * self.speed
        self.vel += (target - self.vel) * 0.3
        if abs(self.vel) < 0.05:
            self.vel = 0.0
        self.x += self.vel

        half = self.width / 2
        if self.x < half:
            self.x = half
            self.vel = 0.0
        elif self.x > screen_width - half:
            self.x = screen_width - half
            self.vel = 0.0

    def get_rect(self):
        return pygame.Rect(
            int(self.x - self.width / 2), int(self.y - self.height / 2),
            self.width, self.height,
        )