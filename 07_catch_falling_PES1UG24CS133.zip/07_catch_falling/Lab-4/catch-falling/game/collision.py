"""
collision: figures out whether a falling object is within the basket.
"""


def is_caught(basket_rect, obj):
    # Closest point on the basket rectangle to the object's center
    nearest_x = max(basket_rect.left, min(obj.x, basket_rect.right))
    nearest_y = max(basket_rect.top, min(obj.y, basket_rect.bottom))
    dx = obj.x - nearest_x
    dy = obj.y - nearest_y
    touching = dx * dx + dy * dy <= obj.radius * obj.radius
    not_below_basket = obj.y <= basket_rect.bottom
    return touching and not_below_basket