"""
GameEngine: owns the basket and all falling objects.
"""

import random
import pygame

from game.basket import Basket
from game.falling_object import FallingObject
from game.collision import is_caught
from game.renderer import WIDTH, HEIGHT

MIN_SPAWN_INTERVAL = 25
MAX_SPAWN_INTERVAL = 70
MAX_OBJECTS = 6
MAX_MISSES = 5
OBJECT_RADIUS = 14
MIN_SPAWN_GAP = 70


class GameEngine:
    def __init__(self):
        self.basket = Basket(x=WIDTH / 2, y=HEIGHT - 30)
        self.objects = []
        self.frames_until_spawn = 0
        self.last_spawn_x = None
        self.score = 0
        self.misses = 0
        self.game_over = False

    def _pick_spawn_x(self):
        lo, hi = OBJECT_RADIUS, WIDTH - OBJECT_RADIUS
        for _ in range(20):
            x = random.randint(lo, hi)
            near_last = (self.last_spawn_x is not None
                         and abs(x - self.last_spawn_x) < MIN_SPAWN_GAP)
            near_obj = any(o.y < 80 and abs(o.x - x) < MIN_SPAWN_GAP for o in self.objects)
            if not near_last and not near_obj:
                return x
        return None

    def _spawn_object(self):
        if len(self.objects) >= MAX_OBJECTS:
            return False
        x = self._pick_spawn_x()
        if x is None:
            return False
        self.objects.append(FallingObject(x=x, y=-OBJECT_RADIUS, radius=OBJECT_RADIUS, speed=3))
        self.last_spawn_x = x
        return True

    def handle_input(self, keys_pressed):
        if self.game_over:
            return
        direction = 0
        if keys_pressed[pygame.K_LEFT]:
            direction -= 1
        if keys_pressed[pygame.K_RIGHT]:
            direction += 1
        if keys_pressed[pygame.K_SPACE]:
            self.basket.activate_boost()
        self.basket.move(direction, WIDTH)

    def handle_keydown(self, key):
        if self.game_over and key == pygame.K_r:
            self.__init__()

    def update(self):
        if self.game_over:
            return

        self.basket.update_boost()

        self.frames_until_spawn -= 1
        if self.frames_until_spawn <= 0:
            if self._spawn_object():
                self.frames_until_spawn = random.randint(MIN_SPAWN_INTERVAL, MAX_SPAWN_INTERVAL)
            else:
                self.frames_until_spawn = 10

        for obj in self.objects:
            obj.update()

        basket_rect = self.basket.get_rect()
        remaining = []
        for obj in self.objects:
            if is_caught(basket_rect, obj):
                self.score += 1
            else:
                remaining.append(obj)
        self.objects = remaining

        missed = [o for o in self.objects if o.is_past_bottom(HEIGHT)]
        if missed:
            self.objects = [o for o in self.objects if not o.is_past_bottom(HEIGHT)]
            self.misses += len(missed)
            if self.misses >= MAX_MISSES:
                self.game_over = True

    def draw(self, surface, font):
        from game import renderer
        renderer.draw_scene(surface, self.basket, self.objects)
        renderer.draw_text(surface, font, f"Score: {self.score}", (10, 10))
        renderer.draw_text(surface, font, f"Misses: {self.misses}/{MAX_MISSES}", (10, 36))
        renderer.draw_boost_status(surface, font, self.basket)

        if self.game_over:
            renderer.draw_banner(surface, font, f"Game Over! Final score: {self.score}. Press R to restart.")