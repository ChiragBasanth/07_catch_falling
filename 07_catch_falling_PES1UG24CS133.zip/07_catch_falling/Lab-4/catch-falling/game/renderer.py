"""
renderer: all pygame drawing lives here, kept separate from game logic.
"""

import pygame

WIDTH, HEIGHT = 700, 500
WINDOW_SIZE = (WIDTH, HEIGHT)

COLOR_BG = (25, 30, 45)
COLOR_BASKET = (150, 110, 70)
COLOR_BASKET_BOOST = (60, 220, 255)
COLOR_TEXT = (255, 255, 255)
COLOR_BOOST = (60, 220, 255)
COLOR_COOLDOWN = (150, 150, 150)
COLOR_READY = (90, 230, 120)


def draw_scene(surface, basket, objects):
    surface.fill(COLOR_BG)
    for obj in objects:
        pygame.draw.circle(surface, obj.color, (int(obj.x), int(obj.y)), obj.radius)
    color = COLOR_BASKET_BOOST if basket.is_boosted else COLOR_BASKET
    rect = basket.get_rect()
    pygame.draw.rect(surface, color, rect, border_radius=6)
    if basket.is_boosted:
        # Outline drawn inside the hitbox so visuals match collisions
        pygame.draw.rect(surface, (255, 255, 255), rect, width=2, border_radius=6)


def draw_boost_status(surface, font, basket):
    x, y, w, h = WIDTH - 260, 12, 240, 14
    if basket.is_boosted:
        label, color, frac = "BOOST ACTIVE!", COLOR_BOOST, basket.boost_fraction()
    elif basket.cooldown_frames_left > 0:
        label, color, frac = "Boost recharging", COLOR_COOLDOWN, 1 - basket.cooldown_fraction()
    else:
        label, color, frac = "Boost READY [SPACE]", COLOR_READY, 1.0
    pygame.draw.rect(surface, (60, 65, 85), (x, y, w, h), border_radius=4)
    pygame.draw.rect(surface, color, (x, y, int(w * frac), h), border_radius=4)
    pygame.draw.rect(surface, COLOR_TEXT, (x, y, w, h), width=1, border_radius=4)
    draw_text(surface, font, label, (x, y + 20), color)


def draw_text(surface, font, text, pos, color=COLOR_TEXT):
    surface.blit(font.render(text, True, color), pos)


def draw_banner(surface, font, text):
    surf = font.render(text, True, (255, 220, 80))
    rect = surf.get_rect(center=(surface.get_width() // 2, surface.get_height() // 2))
    surface.blit(surf, rect)